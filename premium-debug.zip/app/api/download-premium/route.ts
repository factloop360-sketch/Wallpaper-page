import { NextResponse } from "next/server";
import Stripe from "stripe";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";
import { GetObjectCommand } from "@aws-sdk/client-s3";
import { r2 } from "@/lib/r2";
import { createClient } from "@supabase/supabase-js";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, { apiVersion: "2026-04-22.dahlia" as any, });
const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!);

export async function POST(req: Request) {
  try {
    const { sessionId, wallpaperId } = await req.json();

    // 1. Verify the payment with Stripe
    const session = await stripe.checkout.sessions.retrieve(sessionId);
    if (session.payment_status !== "paid") {
      return NextResponse.json({ error: "Payment not completed." }, { status: 402 });
    }

    // 2. Security Check: Has this session already been claimed?
    const { data: transaction } = await supabase
      .from("premium_transactions")
      .select("claimed")
      .eq("stripe_session_id", sessionId)
      .single();

    if (transaction?.claimed) {
      return NextResponse.json({ error: "This secure download link has already been consumed." }, { status: 403 });
    }

    // 3. Fetch the wallpaper filename from Supabase
    const { data: wp } = await supabase.from("wallpapers").select("image_url").eq("id", wallpaperId).single();
    if (!wp) throw new Error("Asset not found");

    // Extract just the filename from your R2 public URL
    const fileName = wp.image_url.split('/').pop()?.split('?')[0]; 

    // 4. Generate the 60-second Presigned URL from Cloudflare R2
    const signedUrl = await getSignedUrl(
      r2,
      new GetObjectCommand({
        Bucket: process.env.R2_BUCKET_NAME,
        Key: fileName,
      }),
      { expiresIn: 60 } // The link literally stops working after 1 minute
    );

    // 5. Burn the token so it can never be used again
    if (!transaction) {
      await supabase.from("premium_transactions").insert({
        stripe_session_id: sessionId,
        wallpaper_id: wallpaperId,
        claimed: true
      });
    }

    return NextResponse.json({ downloadUrl: signedUrl });

  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}